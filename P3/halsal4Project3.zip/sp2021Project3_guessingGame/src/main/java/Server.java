import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.ArrayList;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */
import javafx.util.Pair;

public class Server{

	int port, count = 1;	
//	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	Server(Consumer<Serializable> call, int portNum){
		port = portNum;
		callback = call;
		server = new TheServer();
		server.start();
	}
	public HashMap<String, ArrayList<String>> mapSetup(){
		HashMap<String, ArrayList<String>> m = new HashMap<String, ArrayList<String>>();
		m.put("food", new ArrayList<String>());
		m.get("food").add("pizza");
		m.get("food").add("hotdog");
		m.get("food").add("fries");
		m.get("food").add("chicken");
		m.get("food").add("salad");
		m.get("food").add("steak");
		m.get("food").add("soup");
		m.put("clothing", new ArrayList<String>());
		m.get("clothing").add("pants");
		m.get("clothing").add("shirt");
		m.get("clothing").add("sock");
		m.get("clothing").add("shoe");
		m.get("clothing").add("scarf");
		m.get("clothing").add("jacket");
		m.put("language", new ArrayList<String>());
		m.get("language").add("french");
		m.get("language").add("english");
		m.get("language").add("spanish");
		m.get("language").add("arabic");
		m.get("language").add("russian");
		m.get("language").add("portuguese");
		return m;
	}
	public HashMap<String, Integer> map2Setup(){
		HashMap<String, Integer> m = new HashMap<String, Integer>();
		m.put("food", 0);
		m.put("clothing", 0);
		m.put("language", 0);
		return m;
	}
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(port);){
		    System.out.println("Server is waiting for a client!");
		  
			
		    while(true) {
		
				ClientThread c = new ClientThread(mysocket.accept(), mapSetup(), map2Setup(), count);
				callback.accept("client has connected to server: " + "client #" + count);
//				clients.add(c);
				c.start();
				
				count++;
				
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			
			HashMap<String, ArrayList<String>> map;
			HashMap<String, Integer> attempts;
			Socket connection;
			int count, lives, score;
			String currWord, hiddenWord, currCategory;
			ObjectInputStream in;
			ObjectOutputStream out;
			ClientThread(Socket s, HashMap<String, ArrayList<String>> m,HashMap<String, Integer> m2, int count){
				this.map = m;
				this.attempts = m2;
				this.connection = s;
				this.count = count;	
			}
			
			public void run(){
					
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				 while(true) {
					    try {
					    	Pair<String, String> data = (Pair<String, String>) in.readObject();
					    	callback.accept("client: " + count + " sent: " + data);
					    	readCommand(data);
					    	}
					    catch(Exception e) {
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
//					    	updateClients("Client #"+count+" has left the server!");
//					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run
			
			public void readCommand(Pair<String, String> p) {
				if(p.getKey().equals("cat")) 
					sendHints(p.getValue());
				else if (p.getKey().equals("guess"))
					checkGuess(p.getValue());
				else if(p.getKey().equals("reset"))
					reset();
			}
			public void sendHints(String category) {
				lives = 6;
				currCategory = category;
				ArrayList<String> list = map.get(category);
				Random r = new Random();
				int randIndex = r.nextInt(list.size());
				currWord = list.remove(randIndex);
				hiddenWord = "";
				for(int i = 0; i < currWord.length(); i++)
					hiddenWord = hiddenWord.concat("*");
				try {
					 this.out.writeObject(new Pair<String,String>("show", "guess a " + currWord.length() + " letter " + category));
					 this.out.writeObject(new Pair<String,String>("show", "6 guesses to uncover " + hiddenWord));
					}
					catch(Exception e) {}
			}
			public void checkGuess(String guess) {
				try {
					if(guess.length() != 1) {
						this.out.writeObject(new Pair<String,String>("show", "Invalid guess, guess must be 1 LETTER"));
						return;
					}
					guess = guess.toLowerCase();
					if(currWord.contains(guess)) {
						updateStrings(guess);
						this.out.writeObject(new Pair<String,String>("show", "You guessed correctly: " + hiddenWord));
					}
					else {
						lives--;
						this.out.writeObject(new Pair<String,String>("show", "You guessed incorrectly, " + guess + " is not in the word"));
						this.out.writeObject(new Pair<String,String>("show", "You have " + lives + " guesses left. " + hiddenWord));
						if(lives == 0) {
							if(this.attempts.get(currCategory) >= 2)
								this.out.writeObject(new Pair<String,String>("scene", "lose"));
							else {
								this.attempts.put(currCategory, this.attempts.get(currCategory) + 1);
								this.out.writeObject(new Pair<String,String>("scene", "category"));
							}
						}
					}
				}
				catch(Exception e) {}
			}
			public void updateStrings(String guess) {
				String temp = "";
				for(int i =0; i < currWord.length(); i++) {
					if(currWord.substring(i, i+1).equals(guess))
						temp = temp.concat(guess);
					else if(hiddenWord.charAt(i) != '*') 
						temp = temp.concat(hiddenWord.substring(i, i + 1));
					else
						temp = temp.concat("*");
				}
				hiddenWord = temp;
				for(int i =0; i < hiddenWord.length(); i++) {
					if(hiddenWord.charAt(i) == '*')
						return;
				}
				try {
					score++;
					if(score >= 3)
						this.out.writeObject(new Pair<String,String>("scene", "win"));
					else
						this.out.writeObject(new Pair<String,String>("scene", "category"));
					this.out.writeObject(new Pair<String,String>("disable", currCategory));
				}
				catch(Exception e){}
			}
			public void reset() {
				this.map = mapSetup();
				this.attempts = map2Setup();
				score = 0;
			}
		}//end of client thread
		
}


	
	

	
