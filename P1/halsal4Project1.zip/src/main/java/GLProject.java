// Hussein Alsalahi
// halsal4, halsal4@uic.edu
// Description: A generic list that is extended into a linked list and stack.
// 				The generic list also iterated through with an iterator
//import java.util.ArrayList;

public class GLProject {

	public static void main(String[] args) {
		
		System.out.println("Welcome to project 1");
//		GenericQueue<Integer> myQ = new GenericQueue<>(1);
//		//test1
//		System.out.println("test1");
////		System.out.println(myQ.getLength());
//		myQ.enqueue(2);
//		myQ.enqueue(3);
//		myQ.enqueue(4);
//		myQ.enqueue(5);
//		for(int e: myQ)
//			System.out.print(e);
//		System.out.println();
//		myQ.print();
//		//test2
//		System.out.println("test2");
//		System.out.println(myQ.getLength());
//		System.out.println("dequeued: " + myQ.dequeue());
//		System.out.println("dequeued: " + myQ.dequeue());
//		System.out.println(myQ.getLength());
//
//		//test3
//		System.out.println("test3");
//		myQ.print();
//		ArrayList<Integer> aList = myQ.dumpList();
//		for(Integer e : aList)
//			System.out.println(e);
//		System.out.println(myQ.getLength());
//		myQ.print();
//		System.out.println("**************************");
//		
//		//test1
//		GenericStack<Integer> myStack = new GenericStack<>(1);
//		System.out.println("test1");
//		System.out.println(myStack.getLength());
//		myStack.push(2);
//		myStack.push(3);
//		myStack.push(4);
//		myStack.push(5);
//		//test2
//		System.out.println("test2");
//		System.out.println(myStack.getLength());
//		System.out.println("popped: " + myStack.pop());
//		System.out.println("popped: " + myStack.pop());
//		System.out.println(myStack.getLength());
//
//		//test3
//		System.out.println("test3");
//		myStack.print();
//		ArrayList<Integer> bList = myStack.dumpList();
//		for(Integer e : bList)
//			System.out.println(e);
//		System.out.println(myStack.getLength());
//		myStack.print();

	}
}
