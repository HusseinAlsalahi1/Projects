import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	@Test
	void test() {
		fail("I don't know how to test this project");
	}
	// the way I set up my code makes this very difficult without changing my code
	// my methods don't have parameters
}
